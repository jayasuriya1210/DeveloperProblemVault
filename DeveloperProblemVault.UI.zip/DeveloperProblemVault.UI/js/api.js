const BASE_URL = "http://localhost:5049";

// Get all issues
async function getAllIssues() {

    const response = await fetch(BASE_URL + "/viewIssues");
    return await response.json();

}

// Get one issue
async function getIssue(id) {

    const response = await fetch(BASE_URL + "/viewIssue/" + id);
    return await response.json();

}

// Add issue
async function addIssue(issue) {

    const response = await fetch(BASE_URL + "/addIssue", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify(issue)

    });

    return await response.json();

}